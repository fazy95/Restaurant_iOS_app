//
//  RestaurantObservable.swift
//  Foodeat
//
//  Created by Faizan Elahi on 4/10/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import Foundation
protocol RestaurantObservable: class {
    var id: String?{get}
    var lat: String?{get}
    var long: String?{get}
    var name: String?{get}
    var photo: String?{get}
    var price: String?{get}
    var rating: String?{get}
    var url: String?{get}
    var address: String?{get}
    var restaurants: Favourites?{get}
    func addObserver(observer: RestaurantObserver)
    func removeObserver(observer: RestaurantObserver)
    func notifyObservers()
}
