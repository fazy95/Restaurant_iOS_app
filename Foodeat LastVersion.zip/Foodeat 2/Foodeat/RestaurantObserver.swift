//
//  RestaurantObserver.swift
//  Foodeat
//
//  Created by Faizan Elahi on 4/10/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import Foundation

protocol RestaurantObserver: class {
    func notifyChangedRestaurant(Restaurants: RestaurantObservable)
}
