//
//  Theme.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 30/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit
//manage the app theme
enum Theme: Int {
    case Default
    
    var mainColor: UIColor {
        return UIColor(red: 191/255, green: 156/255, blue: 0/255, alpha: 1.0)
    }
    
    var barStyle: UIBarStyle {
        return .black
    }

    var secondaryColor: UIColor {
       return UIColor(red: 242.0/255.0, green: 101.0/255.0, blue: 34.0/255.0, alpha: 1.0)
        }
    
    var buttonColor: UIColor {
        return UIColor(red: 132/255, green: 11/255, blue: 0/255, alpha: 1.0)
    }
  
    
}


struct ThemeManager {
    
    static func currentTheme() -> Theme {
        if let storedTheme = (UserDefaults.standard.value(forKey : "SelectedTheme") as AnyObject).integerValue {
            return Theme(rawValue: storedTheme)!
        } else {
            return .Default
        }
    }
    
    static func applyTheme(theme: Theme) {
        
        UserDefaults.standard.setValue(theme.rawValue, forKey: "SelectedTheme")
        UserDefaults.standard.synchronize()
        
        let sharedApplication = UIApplication.shared
        sharedApplication.delegate?.window??.tintColor = theme.mainColor
        
        UINavigationBar.appearance().barStyle = theme.barStyle
        UIButton().titleLabel?.font = UIFont(name:"Times New Roman", size: 20)
       
 
    }

}

