//
//  FavouritesListController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 22/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit
 

class FavouritesListController: UITableViewController {
 
     // MARK: - Class Variables
    var model: Model = Model.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //get the favourites list from the database
        model.getFavorite()
        self.tableView.contentInset = UIEdgeInsets(top: 20,left: 0,bottom: 0,right: 0)
        self.tableView.reloadData()
    }
    
    override func  viewDidAppear(_ animated: Bool)
    {
        self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.favouritesDb.count
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavoriteCell", for: indexPath) as UITableViewCell
        cell.imageView?.layer.cornerRadius =   (cell.imageView?.frame.size.width)! / 10
        cell.imageView?.clipsToBounds = true
        let favourite = model.gitFavouriteItem(indexPath)
        var photo = favourite.resturant?.photo
        if (( photo != nil ) && (photo?.count)!>0)
        {
            //to use the jpg format instead og webp
            if(photo?.contains("output-format=webp"))!{
                let photoLen = photo!.count
                let stringLn =  "output-format=webp".count
                let offset = photoLen - stringLn
                photo = String( ( photo?.prefix(offset)  )! )
            }
            let imageUrl = URL(string: photo!)!
            let data = try? Data(contentsOf: imageUrl)
            if let imageData = data {
                cell.imageView?.image = image(UIImage(data: imageData)!, withSize: CGSize(width: 100, height: 100))
            }
        }else{
            cell.imageView?.image = image(UIImage(named: "rest1")!, withSize: CGSize(width: 100, height: 100))
        }
        cell.textLabel?.text = favourite.resturant?.name
        cell.detailTextLabel?.text =  favourite.comment
        cell.accessoryType = UITableViewCellAccessoryType.disclosureIndicator
        return cell
    }
    // MARK : style the restaurant image
    func image( _ image:UIImage, withSize newSize:CGSize) -> UIImage {
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0,y: 0,width: newSize.width,height: newSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!.withRenderingMode(.automatic)
    }
    
    
    // MARK: - Enable Swipe to Delete controller.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        model.deleteFavourite(indexPath)
        self.tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.fade)
    }
    
    // MARK: - Segue methods
    override func prepare(for segue: UIStoryboardSegue, sender: Any!)
    {
        if segue.identifier == "favouritedDeatails" {
            if let dv = segue.destination as? FavouritedDetailsContorller {
                // Send data to the detail view ahead of segue
                if let selectedRowIndexPath = tableView.indexPathForSelectedRow
                {
                    let favourited = self.model.favouritesDb[selectedRowIndexPath.row]
                    dv.currentFavourited = favourited
                }
            }
        }
    }
}
