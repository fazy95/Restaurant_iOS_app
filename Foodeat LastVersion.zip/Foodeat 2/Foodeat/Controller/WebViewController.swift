//
//  WebViewController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 28/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit
import WebKit

class WebViewController: UIViewController  {
    
    // MARK: - Class Variables
    @IBOutlet weak var webView: WKWebView!
    var urlString: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super .viewDidAppear(animated)
        let url : URL = URL(string: "https://www.apple.com/")!
        let urlRequest  = URLRequest(url: url)
        webView.load(urlRequest)
    }
     
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
