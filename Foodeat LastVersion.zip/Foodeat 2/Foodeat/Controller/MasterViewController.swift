
import UIKit

protocol ItemSelectionDelegate: class {
  func itemSelected(_ item: Menu)
}

class MasterViewController: UITableViewController {
    // MARK: - Class Variables
    weak var delegate: ItemSelectionDelegate?
    let items = [
    Menu(name: "Home" ),
    Menu(name: "Clear Search History"  ),
    
  ]
  
 

  // MARK: - Table view data source
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return items.count
  }

  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
    let monster = items[indexPath.row]
    cell.textLabel?.text = monster.name
    return cell
  }

  override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    let selectedItem = items[indexPath.row]
    delegate?.itemSelected(selectedItem)
    //clear the search history
    if (selectedItem .name == "Clear Search History"){
          Model.sharedInstance.deleteRestaurant()
    }else{
    //open the home page 
        if let detailViewController = delegate as? DetailViewController,
        let detailNavigationController = detailViewController.navigationController {
        splitViewController?.showDetailViewController(detailNavigationController, sender: nil)
    }
    }
  }
}

    
  

