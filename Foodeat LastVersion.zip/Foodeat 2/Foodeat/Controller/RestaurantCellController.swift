//
//  RestaurantCellController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 22/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit

class RestaurantCellController: UITableViewCell {

    // MARK: - Class Variables
    @IBOutlet weak var restName: UILabel!
    @IBOutlet weak var restImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
