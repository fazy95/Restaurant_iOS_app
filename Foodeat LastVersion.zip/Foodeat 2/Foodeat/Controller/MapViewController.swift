//
//  MapViewController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 28/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit

import CoreLocation
import MapKit


class MapViewController: UIViewController {
    
    // MARK: - Class Variables
    fileprivate let locationManager = CLLocationManager()
    @IBOutlet var mapView:MKMapView!
    var initialLocation : CLLocation?
    var currentResturant : Restaurants?
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        if (CLLocationManager.locationServicesEnabled() ){
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            let latitude = currentResturant?.lat
            let longitude = currentResturant?.long
            // set initial location for the map
            initialLocation =  CLLocation (latitude: (  latitude! as NSString).doubleValue , longitude:  (longitude! as NSString).doubleValue )
        } else{
            locationManager.requestWhenInUseAuthorization()
        }
    }
}

extension MapViewController:CLLocationManagerDelegate{
    // Tells the delegate that location data is available.
    func locationManager(_ manager: CLLocationManager, didUpdateLocations
        locations: [CLLocation]) {
        
        let restaurantLocation = initialLocation!
        if restaurantLocation.horizontalAccuracy > 100 ||
                restaurantLocation.verticalAccuracy > 50 {
                return
            }
        mapView.addAnnotation(Place(title:(currentResturant?.name)!,
                coordinate:restaurantLocation.coordinate))
        // Control the zoom on the map.  The smaller the value the closer the zoom
        // Center, N/S, E/W
        let region = MKCoordinateRegionMakeWithDistance(restaurantLocation.coordinate, 500, 500)
        mapView.setRegion(region, animated: true)
    }
    
    // When the authorisation is given by the user, this
    // method is called and we ask to start providing
    // the location data.
    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            locationManager.startUpdatingLocation()
            mapView.showsUserLocation = true
        default:
            locationManager.stopUpdatingLocation()
            mapView.showsUserLocation = false
        }
    }
    
    // Create an alert showing the user that permission
    // was denied.
    func locationManager(_ manager: CLLocationManager,
                         didFailWithError error: Error) {
        let errorType = error._code == CLError.Code.denied.rawValue
            ? "Access Denied": "Error \(error._code)"
        let alertController = UIAlertController(title: "Location Manager Error",
                                                message: errorType, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .cancel,
                                     handler: { action in })
        alertController.addAction(okAction)
        present(alertController, animated: true,
                completion: nil)
    }
    func get(formatted provided: String, string: String) -> String{
        
        return String(format: provided,
                      string)
    }
}
//class to show the mark on the map 
class Place: NSObject, MKAnnotation {
    let title: String?
    var coordinate: CLLocationCoordinate2D
    
    init(title:String,  coordinate:CLLocationCoordinate2D) {
        self.title = title
        self.coordinate = coordinate
    }
}
