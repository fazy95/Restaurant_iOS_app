//
//  RestaurantDetailsController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 22/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit
import MapKit


class RestaurantDetailsController: UIViewController , RestaurantObserver {
    
    // MARK: - Class Variables
    @IBOutlet weak var restRating: UILabel!
    @IBOutlet weak var restLocation: UILabel!
    @IBOutlet weak var restPrice: UILabel!
    @IBOutlet weak var resImage: UIImageView!
    @IBOutlet weak var restName: UILabel!
    var model:Model = Model.sharedInstance
    var currentResturant:Restaurants?
    @IBOutlet weak var favouriteButton: UIButton!{
        //style the button
        didSet{
            buttonStyle(button: favouriteButton)
        }
    }
    @IBOutlet weak var webPageButton: UIButton!{
        //style the button
        didSet{
            buttonStyle(button: webPageButton)
        }
    }
    @IBOutlet weak var showLocationButton: UIButton!{
        //style the button
        didSet{
            buttonStyle(button: showLocationButton)
        }
    }
    //Mark : observable variable
    weak var restaurantObservable: RestaurantObservable?{
        willSet{
            restaurantObservable?.removeObserver(observer: self)
            if let value = newValue{
                value.addObserver(observer: self)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
 
    override func viewDidLoad()
    {
          super.viewDidLoad()
        if let _ = currentResturant
        {
            //fill restaurant details from resataurant object
            restRating.text = String ( describing:  (currentResturant?.rating)!)
            restName.text = currentResturant?.name
            restPrice.text = (currentResturant?.price)!
            restLocation.text =  currentResturant?.address
            var photo = currentResturant?.photo
            resImage.layer.cornerRadius = self.resImage.frame.size.width / 10
            resImage.clipsToBounds = true
            if (( photo != nil ) && (photo?.count)!>0)
            {
                //to use the jpg format instead og webp
                if(photo?.contains("output-format=webp"))!{
                    let photoLen = photo!.count
                    let stringLn =  "output-format=webp".count
                    let offset = photoLen - stringLn
                    photo = String( ( photo?.prefix(offset)  )! )
                }
                let imageUrl = URL(string: photo!)!
                let data = try? Data(contentsOf: imageUrl)
                if let imageData = data {
                    resImage.image = UIImage(data: imageData)
                }
            }else{
                resImage.image =  UIImage(named: "rest1")
            }
        }
    }
 
    
    
    //MARK: - add a restaurant to favourite list
    @IBAction func addToFavourites(_ sender: UIButton) {
        let isFavorited = model.addFavorite(fav_comment: " ", resturant: currentResturant!)
            if(isFavorited){
                let alertController = UIAlertController(title: "Added", message:
                    "", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }else{
                let alertController = UIAlertController(title: "Restaurant is already added!", message:
                    "", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
            }
        }
    
    //MARK: - button style function
    func buttonStyle ( button : UIButton ){
        button.backgroundColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0)
        button.layer.cornerRadius = 7
        button.layer.borderWidth = 2
        button.layer.borderColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0).cgColor
    }
    
    // MARK: - Segue methods
    override func prepare(for segue: UIStoryboardSegue, sender: Any!)
    {
        if segue.identifier == "website" {
            if let dv = segue.destination as? WebViewController {
                dv.urlString = currentResturant?.url
                
            }
        }
        if segue.identifier == "map" {
            if let dv = segue.destination as? MapViewController {
                dv.currentResturant = currentResturant 
            }
        }
    }
    
    // MARK: -  function to notify the observer
    func notifyChangedRestaurant(Restaurants: RestaurantObservable) {
        currentResturant?.id = Restaurants.id
        currentResturant?.lat = Restaurants.lat
        currentResturant?.long = Restaurants.long
        currentResturant?.name = Restaurants.name
        currentResturant?.photo = Restaurants.photo
        currentResturant?.price = Restaurants.price
        currentResturant?.rating = Restaurants.rating
        currentResturant?.url = Restaurants.url
        currentResturant?.address = Restaurants.address
        currentResturant?.restaurants = Restaurants.restaurants
        
    }
    
}

