//
//  FavouritedDetailsContorller.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 22/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit
class FavouritedDetailsContorller: UIViewController {

    // MARK: - Class Variables
    var currentFavourited: Favourites?
    @IBOutlet weak var resName: UILabel!
    @IBOutlet weak var comment: UITextView!
    @IBOutlet weak var saveButton: UIButton!{
        //style the button
        didSet{
            buttonStyle(button: saveButton)
        }
    }
    @IBOutlet weak var restaurantButton: UIButton!{
        //style the button
        didSet{
        buttonStyle(button: restaurantButton)
        }
    }
    
    //function to use custome style
    func buttonStyle ( button : UIButton ){
        button.backgroundColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0)
        button.layer.cornerRadius = 7
        button.layer.borderWidth = 2
        button.layer.borderColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0).cgColor
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let _ = currentFavourited
        {
            resName.text = currentFavourited?.resturant?.name
            comment.text = currentFavourited?.comment
        }
        //custome design for the text area
        let borderColor : UIColor = UIColor(red: 0.85, green: 0.85, blue: 0.85, alpha: 1.0)
        comment.layer.borderColor = borderColor.cgColor
        comment.layer.borderWidth = 0.5;
        comment.layer.cornerRadius = 5;
        comment.clipsToBounds = true;
     
    }

    // MARK: - Segue methods
    override func prepare(for segue: UIStoryboardSegue, sender: Any!)
    {
        if segue.identifier == "viewRestaurant" {
            if let dv = segue.destination as? RestaurantDetailsController {
                dv.currentResturant = currentFavourited?.resturant
            }
        }
    }
    
    // MARK: - update comment
    @IBAction func saveUpdateFavourited(_ sender: Any) {
        Model.sharedInstance.saveFavorite(fav_comment: comment.text, favourite: currentFavourited!)
        self.navigationController?.popViewController(animated: true)
    }

}



