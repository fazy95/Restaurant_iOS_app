import UIKit

import CoreLocation


class DetailViewController: UIViewController ,APIDelegate, CLLocationManagerDelegate {
    
    // MARK: - Class Variables
    var model:Model = Model.sharedInstance
    var api : API?
    var latitude : Double?
    var longitude : Double?
    var city : String?
    var isCurrentLocationUsed = false
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var searchText: UITextField!
    @IBOutlet var homePageView: UIView!
    let locationManager = CLLocationManager()
    var menuItem: Menu? {
        didSet {
                loadViewIfNeeded()
        }
    }
     //style the search button
    @IBOutlet weak var searchButton: UIButton!{
       
        didSet{
            searchButton.backgroundColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0)
            searchButton.layer.cornerRadius = 7
            searchButton.layer.borderWidth = 2
            searchButton.layer.borderColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0).cgColor        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Set delegates before displaying the view
        if api?.delegate == nil{
            api = FoodeatAPI.sharedInstance
            api?.delegate = self as APIDelegate
        }
        //request permission to use location
        locationManager.requestWhenInUseAuthorization()
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //change the background color of the main page
        self.view.backgroundColor = UIColor(red: 219/255, green: 219/255, blue: 219/255, alpha: 1.0)
    }
    
    //Location authentication
    func setupLocationManager() {
        locationManager.delegate = self as? CLLocationManagerDelegate
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    //get current location using the location manager
    @IBAction func useCurrentLocation(_ sender: Any) {
        // Property for asking for the current authorisation
        // status obtained from the app settings.
        switch CLLocationManager.authorizationStatus()
        {
        case .authorizedAlways, .authorizedWhenInUse:
            
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            guard let locValue: CLLocationCoordinate2D = locationManager.location?.coordinate else { return }
            latitude = locValue.latitude
            longitude = locValue.longitude
            //call the api to get the city name for this coordinates
            api?.getCityName(latitude :  String(format:"%f",  latitude!), longitude: String(format:"%f",  longitude!))
            //sit the text box to the city name
            searchText.text = city
            //flag to indicate that the current location is used
            isCurrentLocationUsed = true
            break
       
        case .denied, .notDetermined , .restricted :
            customAlert(title: "To use the app you need to allow the location permissions", message: "Go to Settings?", actionTitle: "Cancel")
        }
    }
    
    // Create an alert that allows the user to navigate to settings
    // to modify the permissions.
    func customAlert(title: String, message: String, actionTitle: String)
    {
        let alert = UIAlertController (title: title, message: message, preferredStyle: .alert)
        let settingsAction = goToSettings()
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(settingsAction)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
    }
    
    // Create an action for navigating to settings for this app.
    func goToSettings() -> UIAlertAction{
        return UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
            guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                return
            }
            // Open the applications settings.
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                })
            }
        }
    }
    
    //search for restaurants
    @IBAction func search(_ sender: UIButton) {
         if(isCurrentLocationUsed) // search using user location
        {
            api?.getRestaurants(latitude:  String(format:"%f",  latitude!), longitude: String(format:"%f",  longitude!) )
             isCurrentLocationUsed = false
        }else if ((searchText.text?.count)! > 0  )   // serach by city name
            
        {
            //replace spaces in the query with "_"
            let cityName : String = (searchText.text?.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: " ", with: "_"))!
            
            //call api to locate city lat and long
            (api?.getCoordinates(cityName: cityName))!
        }
        // navigate to the results view
        let restaurantsListVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ResrtaurantsListController") as! ResrtaurantsListController
        self.navigationController?.pushViewController(restaurantsListVC, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   
    // when user location used notify me to change the text box to city name
    func onCityNameReady(cityName: String) {
        city  =  cityName
    }
}

// delgate used for split view
extension DetailViewController: ItemSelectionDelegate {
  func itemSelected(_ item: Menu) {
    menuItem = item
  }
}
