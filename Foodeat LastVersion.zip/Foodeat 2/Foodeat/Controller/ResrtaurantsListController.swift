//
//  ResrtaurantsListController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 22/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit

class ResrtaurantsListController: UITableViewController {

    // MARK: - Class Variables
    var model:Model = Model.sharedInstance

    @IBOutlet var resTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
   
    // MARK: - Populate the table view
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.restaurantsDb.count
    }

    // MARK: - Prepare data for display
    override func  viewDidAppear(_ animated: Bool)
    {
        self.tableView.reloadData()
    }
    
    // Just prior to the view appearing, get the latest copy of restaurants from the model
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        model.getRestaurants()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RestaurantCellController", for: indexPath) as! RestaurantCellController
        let restaurant = model.getRestaurant(indexPath)
        var photo = restaurant.photo
        
        if (( photo != nil ) && (photo?.count)!>0)
        {
            //to use the jpg format instead og webp
            if(photo?.contains("output-format=webp"))!{
                let photoLen = photo!.count
                let stringLn =  "output-format=webp".count
                let offset = photoLen - stringLn
                photo = String( ( photo?.prefix(offset)  )! )
            }
            print(photo!)
            let imageUrl = URL(string: photo!)!
            let data = try? Data(contentsOf: imageUrl)
            if let imageData = data {
                cell.restImage.image = UIImage(data: imageData)
            }
        }else{
            //use default image if the api dosent has one
            cell.restImage.image =  UIImage(named: "rest1")
        }
       
        cell.restName.text = restaurant.name
        return cell
    }
    

    // MARK: - Segue methods
    override func prepare(for segue: UIStoryboardSegue, sender: Any!)
    {
        if segue.identifier == "resDetails" {
            if let dv = segue.destination as? RestaurantDetailsController {
                // Send data to the detail view ahead of segue
                if let selectedRowIndexPath = tableView.indexPathForSelectedRow
                {
                    let restaurant = self.model.restaurantsDb[selectedRowIndexPath.row]
                    dv.currentResturant = restaurant
                }
            }
        }
    }
    
    //add a restaurant to the favourite list
    @IBAction func addToFavourites(_ sender: UIButton) {
        var superView = sender.superview
        while !(superView is UITableViewCell) {
            superView = superView?.superview
        }
        let cell = superView as! UITableViewCell
        if let indexpath = tableView.indexPath(for: cell){
            let currentRestaurant = model.restaurantsDb[indexpath.row]
            // if succefuly added -> alert: success , else -> duplicated, alert the user
            let isFavorited = model.addFavorite(fav_comment: " ", resturant: currentRestaurant)
            if(isFavorited){
                let alertController = UIAlertController(title: "Added", message:
                    "", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }else{
                let alertController = UIAlertController(title: "Restaurant is already added!", message:
                    "", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
    }
    
}
