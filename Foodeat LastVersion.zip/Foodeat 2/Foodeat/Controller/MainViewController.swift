//
//  MainViewController.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 22/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
class MainViewController: UIViewController ,APIDelegate, CLLocationManagerDelegate {
    func foundCityName(found: Bool) {
        <#code#>
    }
    

    @IBOutlet weak var searchButton: UIButton!{
        didSet{
            searchButton.backgroundColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0)
            searchButton.layer.cornerRadius = 7
            searchButton.layer.borderWidth = 2
            searchButton.layer.borderColor = UIColor(red: 132/255, green: 22/255, blue: 35/255, alpha: 1.0).cgColor        }
    
    }
    @IBOutlet weak var searchText: UITextField!
    var model:Model = Model.sharedInstance
    var api : API?
   
    var isCurrentLocationUsed = false
    var latitude : Double?
    var longitude : Double?
 
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 219/255, green: 219/255, blue: 219/255, alpha: 1.0) 

        
    }
    

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        
    }
    
    
    //Location auth
    let locationManager = CLLocationManager()
    
    func setupLocationManager() {
        locationManager.delegate = self as? CLLocationManagerDelegate
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        
    }
    
    func onCityNameReady(cityName: String) {
        print("MainViewController: \(cityName)");
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Set delegates before displaying the view
        if api?.delegate == nil{
            api = FoodeatAPI.sharedInstance
            api?.delegate = self
        }
        
    }
    @IBAction func useCurrentLocation(_ sender: Any) {
        // Property for asking for the current authorisation
        // status obtained from the app settings.
        switch CLLocationManager.authorizationStatus()
        {
        case .authorizedAlways, .authorizedWhenInUse, .notDetermined:
            customAlert(title: "Would you like to deny permissions", message: "Go to Settings?", actionTitle: "Cancel")
            
        case .denied:
            customAlert(title: "Would you like to allow permissions", message: "Go to Settings?", actionTitle: "Cancel")
            
        case .restricted:
            // Nothing you can do, app cannot use location services
            break
        }
        
        
       
        
        if CLLocationManager.locationServicesEnabled() {
       
            print( "if")
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            guard let locValue: CLLocationCoordinate2D = locationManager.location?.coordinate else { return }
              print("locations = \(locValue.latitude) \(locValue.longitude)")
            latitude = locValue.latitude
            longitude = locValue.longitude
              api?.getCityName(latitude :  String(format:"%f",  latitude!), longitude: String(format:"%f",  longitude!))
            isCurrentLocationUsed = true
            
            
        }else {
            print("else")
            // Ask for Authorisation from the User.
            self.locationManager.requestAlwaysAuthorization()
            
        }
    }
   
    // Create an alert that allows the user to navigate to settings
    // to modify the permissions.
    func customAlert(title: String, message: String, actionTitle: String)
    {
        let alert = UIAlertController (title: title, message: message, preferredStyle: .alert)
        let settingsAction = goToSettings()
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alert.addAction(settingsAction)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
        
    }
    
    // Create an action for navigating to settings for this app.
    func goToSettings() -> UIAlertAction{
        return UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
            
            guard let settingsUrl = URL(string: UIApplicationOpenSettingsURLString) else {
                return
            }
            
            // Open the applications settings.
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)") // Prints true
                })
            }
        }
    }
    
    
    
    
    @IBAction func search(_ sender: UIButton) {
        
        if(isCurrentLocationUsed)     // search using user location

        {
            api?.getRestaurants(latitude:  String(format:"%f",  latitude!), longitude: String(format:"%f",  longitude!) )
            return
            
        }else if ((searchText.text?.count)! > 0  )   // serach by city name
        
        {
            
            
            //call api to locate city lat and long
              (api?.getCoordinates(cityName: searchText.text!))!
            print(searchText.text!)
               return
            
            
        }
        
       
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

