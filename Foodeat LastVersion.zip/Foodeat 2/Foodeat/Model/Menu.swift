 
import UIKit
 
class Menu {
  let name: String
    
  init(name: String ) {
    self.name = name
  }
 
 
}
