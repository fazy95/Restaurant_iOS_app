//
//  Model.swift
//  Assignment2
//
//  Created by sarah almaghrabi on 10/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class Model{

    
    // MARK: - Class Variables
    static let sharedInstance = Model()
    var favouritesDb = [Favourites]()
    var restaurantsDb = [Restaurants]()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let managedContext: NSManagedObjectContext
    
    // Singleton design pattern
    private init()
    {
        managedContext = appDelegate.persistentContainer.viewContext
    }
    
    /// Delete a favourite item
    ///
    /// - Parameter indexPath: indexPath of seleceted item
    func deleteFavourite(_ indexPath : IndexPath)
    {
        let favorite = favouritesDb[indexPath.item]
        favouritesDb.remove(at: indexPath.item)
        managedContext.delete(favorite)
        updateDatabase()
    }
    
    /// Save changes to local database
    ///
    ///
     func updateDatabase() {
        do
        {
            try managedContext.save()
        }
        catch let error as NSError
        {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    /// Get All favourites
    ///
    /// - Returns: Array of all favourite items
    func getFavorite()
    {
        do
        {
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Favourites")
            let results = try managedContext.fetch(fetchRequest)
            favouritesDb = results as! [Favourites]
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
     }
   
  
    /// update favourites
    ///
    /// - parameters: comment and favorite obj
    func saveFavorite(fav_comment : String , favourite : Favourites ) -> Bool{
      getFavorite()
        for item in favouritesDb{
            if( item.resturant == favourite.resturant)
           {
                favourite.comment = fav_comment
                item.comment = fav_comment
                updateDatabase()
                return true;
            }
        }
        
      
        return false;
    }

    // Add favourites
    ///
    /// - parameters: comment ,  resturant
    /// - Returns: Bool
    func addFavorite(fav_comment : String , resturant : Restaurants) -> Bool{
        let entity = NSEntityDescription.entity(forEntityName: "Favourites", in: managedContext)
        if (isResturantAddedToFav( resturant) ) {
            // avoid adding the same returant to the favourites list
            return false
        }
        
        let favourite = NSManagedObject(entity: entity! , insertInto: managedContext) as! Favourites
        favourite.setValue(fav_comment, forKey: "comment")
        favourite.setValue(resturant, forKey: "resturant")
        favouritesDb.append(favourite)
        
        updateDatabase()
        return true
    }
    
    ///Check if restaurant is already added to favourites
    ///
    ///
    /// - parameters: resturant
    /// - Returns: Bool
    func isResturantAddedToFav(_ resturant : Restaurants) -> Bool{
        getFavorite()
        for  item in favouritesDb{
            if( item.resturant == resturant)
            {
                 return true
            }
        }
         return false
    }
    
    /// Get  restaurant item
    ///
    /// - parameters: indexPath
    /// - Returns: restaurant item
    func getRestaurant(_ indexPath: IndexPath) -> Restaurants
    {
        return restaurantsDb[indexPath.row]
    }
 
    /// Get  restaurant item
    ///
    /// - parameters: restaurantID
    /// - Returns: restaurant item
    func getRestaurant(_ id: String) -> Restaurants?
    {
        getRestaurants()
        for  item in restaurantsDb{
            if( item.id ==  id)
            {
                return item
            }
        }
        return nil
    }
    
    /// Get  favourite item
    ///
    /// - parameters: indexPath
    /// - Returns: favourite item
    func gitFavouriteItem(_ indexPath : IndexPath ) -> Favourites{
        return favouritesDb[indexPath.row]
    }
    
    /// Get  favourite item
    ///
    /// - parameters: restaurantID
    /// - Returns: favourite item
    func gitFavouriteItem(_ id : String ) -> Favourites?{
        getFavorite()
        for  item in favouritesDb{
            if( item.resturant?.id ==  id)
            {
                return item
            }
        }
        return nil
    }
    
    
    
    /// Get All Resturants
    ///
    /// - Returns: Array of all resturants
    func getRestaurants( )
    {
        do
        {
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Restaurants")
            let results = try managedContext.fetch(fetchRequest)
            restaurantsDb = results as! [Restaurants]
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    /// Add Restaurant
    ///
    /// - parameters: id, name, photoName, rating, price, lat , long ,address  , url
    func addRestaurant( id : String , name : String , photoName : String , rating : String , price : String ,
                        lat : String , long : String , address : String , url : String) -> Bool
    {
        let entity = NSEntityDescription.entity(forEntityName: "Restaurants", in: managedContext)
        if (isRestaurantExist( id) ) {
            // avoid adding the same returant to the Resturant DB
           return false
        }
        let restaurant = Restaurants(entity: entity! , insertInto: managedContext)
        restaurant.id = id
        restaurant.name = name
        restaurant.photo = photoName
        restaurant.rating = rating
        var temp : String = ""
        var i = 0
        while( i < Int(price)! ){
            temp+="$"
            i = i + 1
        }
        restaurant.price = temp
        restaurant.lat = lat
        restaurant.long =   long
        restaurant.address = address
        restaurant.url = url
        updateDatabase()
        return true
    }
    
    ///Check if restaurant is already exisit in the DB
    ///
    ///
    /// - parameters: id
    /// - Returns: Bool
    func isRestaurantExist(_ id : String) -> Bool{
        getRestaurants()
        for  item in restaurantsDb{
            if( item.id ==  id)
            {
                return true
            }
        }
        return false
    }
    
    /// Delete restaurants list from the DB
    ///
    ///
    func deleteRestaurant( )
    {
            let appDel:AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
            let context:NSManagedObjectContext = appDel.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Restaurants")
            fetchRequest.returnsObjectsAsFaults = false
            do
            {
                let results = try context.fetch(fetchRequest)
                for managedObject in results
                {
                    let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                    context.delete(managedObjectData)
                }
                restaurantsDb.removeAll()
            } catch let error as NSError {
                print("Deleted all my data in myEntity error : \(error) \(error.userInfo)")
            }
        updateDatabase()
        
    }
}
