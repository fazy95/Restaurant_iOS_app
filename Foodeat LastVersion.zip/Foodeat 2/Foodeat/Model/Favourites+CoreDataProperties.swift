//
//  Favourites+CoreDataProperties.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 4/10/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//
//

import Foundation
import CoreData


extension Favourites {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Favourites> {
        return NSFetchRequest<Favourites>(entityName: "Favourites")
    }

    @NSManaged public var comment: String?
    @NSManaged public var resturant: Restaurants?

}
