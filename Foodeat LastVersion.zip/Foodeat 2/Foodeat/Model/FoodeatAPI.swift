//
//  FoodeatAPI.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 27/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import Foundation
class FoodeatAPI : API {
   
    
    
    // MARK: - Class Variables
    static let sharedInstance = FoodeatAPI()
    var delegate: APIDelegate?
    let session = URLSession.shared
    let zomatoKey = "3d9c07335a60712535d6d2d67ce77626"
    
    private init(){}
   
    // MARK: - API Functions
    /// Get restaurants list from server
    func getRestaurants(latitude: String, longitude: String) {
        // create new requets with REST API URL
        let urlString = "https://developers.zomato.com/api/v2.1/search?&lat=\(latitude)&lon=\(longitude)";
        var request = URLRequest(url:  NSURL(string: urlString)! as URL)
        // API Key header
        request.addValue(zomatoKey, forHTTPHeaderField: "user_key")
        // tell the API to return json only
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpMethod = "GET"
        
        // URL request task
        let task = session.dataTask(with: request, completionHandler: {data, response, error in
            
            // Request error
            if let er = error
            {
                self.delegate?.didRetrieveDataError?(error: er as NSError)
            }
            else
            {
                // holds the response
                let parsedResult: Any!
                do
                {
                    // Convert results to JSON object
                    parsedResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                }catch _ as NSError
                {
                    parsedResult = nil
                }
                catch
                {
                    fatalError()
                }
 
                if let results = (parsedResult as? NSDictionary)?.value(forKey: "restaurants") as? NSArray {
                        if let result = results.value(forKey: "restaurant") as? NSArray {
                            for r in result {
                                // Extract restaurant info from JSON
                                let  restaurantName = (r as AnyObject).value(forKey: "name")
                                let  rating = (r as AnyObject).value(forKey: "user_rating")
                                let aggregate_rating = (rating! as AnyObject).value(forKey : "aggregate_rating")
                                let  id = (r as AnyObject).value(forKey: "id")
                                let location = (r as AnyObject).value(forKey: "location")
                                let latitude =  (location! as AnyObject).value(forKey : "latitude")
                                let longitude =  (location! as AnyObject).value(forKey : "longitude")
                                let address =  (location! as AnyObject).value(forKey : "address")
                                let price_range = (r as AnyObject).value(forKey: "price_range")
                                let photo = (r as AnyObject).value(forKey: "featured_image")
                                let url = (r as AnyObject).value(forKey: "url")
                                // Add restaurant to the database
                                let result =  Model.sharedInstance.addRestaurant(id: id as! String, name: restaurantName as! String, photoName: photo! as! String , rating:  aggregate_rating as! String, price:  "\(String(describing: price_range!))", lat: latitude as! String , long: longitude as! String, address: address as! String, url: url as! String )
                        }
                    }else{
                            // wrong json data, sent by server
                            self.delegate?.didRetrieveDataError!(error: NSError())
                         }
                    
                }
            }
        })
        
        // run the task
        task.resume()
    }

    
    
    /// Get City coordinates
    func getCoordinates(cityName: String)  {
        // create new requets with REST API URL
        let urlString = "https://developers.zomato.com/api/v2.1/locations?query=\(cityName)";
        var request = URLRequest(url:  NSURL(string: urlString)! as URL)
        // API Key header
        request.addValue(zomatoKey, forHTTPHeaderField: "user_key")
        // tell the API to return json only
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpMethod = "GET"
        
        
        // URL request task
        let task = session.dataTask(with: request, completionHandler: {data, response, error in
            
            // Request error
            if let er = error
            {
                self.delegate?.didRetrieveDataError?(error: er as NSError)
            }
            else
            {
                // holds the response
                let parsedResult: Any!
                do
                {
                    // Convert results to JSON object
                    parsedResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                   
                }catch _ as NSError
                {
                    parsedResult = nil
                }
                catch
                {
                    fatalError()
                }
                if let results = (parsedResult as? NSDictionary)?.value(forKey: "location_suggestions") as? NSArray {
                    if( results.count > 0 )
                    {
                    
                   
                        // Extract lat and long  from JSON
                    var latitude =  results.value(forKey: "latitude")
                    var longitude = results.value(forKey: "longitude")
                    
                    //  replacingOccurrences(of: "\"", with: " ")
                    var temp = String(describing: latitude).split(separator:  "\"", maxSplits: 3, omittingEmptySubsequences: true)
                    latitude = String(temp[1])
                    temp = String(describing: longitude).split(separator:  "\"", maxSplits: 3, omittingEmptySubsequences: true)
                    longitude = String(temp[1])
                    longitude  = String(describing: longitude)
                    
                        self.getRestaurants(latitude:  latitude as! String ,  longitude: longitude as! String)
                     }
                }else{
                    // wrong json data, sent by server
                    self.delegate?.didRetrieveDataError!(error: NSError())
 
                    
                }
                
                
            }
        })
        
        // run the task
        task.resume()
    }
    
    
    /// Get City name
    func getCityName(latitude : String, longitude : String)  {
        
        
        // create new requets with REST API URL
        let urlString = "https://developers.zomato.com/api/v2.1/geocode?lat=\(latitude)&lon=\(longitude)";
        
        
        var request = URLRequest(url:  NSURL(string: urlString)! as URL)
        // API Key header
        request.addValue(zomatoKey, forHTTPHeaderField: "user_key")
        // tell the API to return json only
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpMethod = "GET"
        
        
        // URL request task
        let task = session.dataTask(with: request, completionHandler: {data, response, error in
            
            // Request error
            if let er = error
            {
                self.delegate?.didRetrieveDataError?(error: er as NSError)
            }
            else
            {
                // holds the response
                let parsedResult: Any!
                do
                {
                    // Convert results to JSON object
                    parsedResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.allowFragments)
                    
                }catch _ as NSError
                {
                    parsedResult = nil
                }
                catch
                {
                    fatalError()
                }
                
                if let results = (parsedResult as AnyObject).value(forKey: "location")  {
                                
                     // Extract cityName  from JSON
                     let cityName =  (results as AnyObject).value(forKey: "city_name")
                    let name: String = cityName as! String;
                    self.delegate!.onCityNameReady(cityName: name);
                }else{
                    // wrong json data, sent by server
                    self.delegate?.didRetrieveDataError!(error: NSError())
 
                }
            
                
            }
        })
        
        // run the task
        task.resume()
       

    }
    
}
