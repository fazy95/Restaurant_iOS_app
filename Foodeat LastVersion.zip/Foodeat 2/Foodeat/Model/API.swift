//
//  API.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 27/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

 import Foundation

/// API delegate functions
@objc protocol APIDelegate {
    
    /*
    Error: Data is not retrieved
    /// Called when there is an error while retrieving data from the server
    /// - Parameter error: error object
    */
    @objc optional func didRetrieveDataError(error: NSError)
    
    /*
     /// Called when there is a change in the city name
     ///
     /// - parameter: cityName
     */
    @objc func onCityNameReady(cityName: String)
   
    
    
}
protocol API {
    
    var delegate: APIDelegate? { get set }
    
    /// Get resturants list from server
    ///
    /// This will return the restaurants list from the server baseed on the
    /// user's location
    /// - Parameters:
    ///   - latitude
    ///   - longitude
    func getRestaurants(latitude : String, longitude : String)
    
    /// Get city coordinates from server
    ///
    ///  
    ///
    /// - Parameters:
    ///   - city name
    ///   
    func getCoordinates(cityName : String)
    
    /// Get city name
    ///
    ///
    ///
    /// - Parameters:
    ///   - latitude
    ///   - longitude
    func getCityName(latitude : String, longitude : String)
}
