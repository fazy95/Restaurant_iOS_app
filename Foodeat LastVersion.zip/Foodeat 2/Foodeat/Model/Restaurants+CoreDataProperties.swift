//
//  Restaurants+CoreDataProperties.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 4/10/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//
//

import Foundation
import CoreData


extension Restaurants {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Restaurants> {
        return NSFetchRequest<Restaurants>(entityName: "Restaurants")
    }

    @NSManaged public var address: String?
    @NSManaged public var id: String?
    @NSManaged public var lat: String?
    @NSManaged public var long: String?
    @NSManaged public var name: String?
    @NSManaged public var photo: String?
    @NSManaged public var price: String?
    @NSManaged public var rating: String?
    @NSManaged public var url: String?
    @NSManaged public var restaurants: Favourites?

}
