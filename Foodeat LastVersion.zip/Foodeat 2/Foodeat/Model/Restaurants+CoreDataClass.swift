//
//  Restaurants+CoreDataClass.swift
//  Foodeat
//
//  Created by sarah almaghrabi on 27/9/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Restaurants)
public class Restaurants: NSManagedObject {

}
