//
//  FoodeatTests.swift
//  FoodeatTests
//
//  Created by sarah almaghrabi on 6/10/18.
//  Copyright © 2018 sarah almaghrabi. All rights reserved.
//

import XCTest
@testable import Foodeat
class FoodeatTests: XCTestCase  {
    
    // Database model reference
    let model =  Model.sharedInstance
    
    override func setUp() {
        super.setUp()
        //restaurant will be added to be tested against already existed restaurants and add favourite
        model.addRestaurant(id: "100100", name: "LiTTle LLAMA Café", photoName: "https://b.zmtcdn.com/data/pictures/0/18702400/fc47e77bdd5bc3b73cf617eeafb3931c.jpg?fit=around%7C200%3A200&crop=200%3A200%3B%2A%2C%2A", rating: "4.0", price: "3", lat: "30.4552247493", long: "78.0827539042", address: "1, London House, Picture Palace, Mussoorie", url: "https://www.zomato.com/mussoorie/little-llama-café-the-mall-road?utm_source=api_basic_user&utm_medium=api&utm_campaign=v2.1")
        model.getRestaurants()
        
        
    }
    
    override func tearDown() {
       
        super.tearDown()
        model.deleteRestaurant()
    }
    
    
    /// Test adding a restaurant
    ///
    /// Business logic:
    /*
        - The app should enable new restaurants to be added to the DB
     
    */
    func testAddingRestaurant(){
        //create a restaurant object and add it to the db
        let response = model.addRestaurant(id: "18702400", name: "LiTTle LLAMA Café", photoName: "https://b.zmtcdn.com/data/pictures/0/18702400/fc47e77bdd5bc3b73cf617eeafb3931c.jpg?fit=around%7C200%3A200&crop=200%3A200%3B%2A%2C%2A", rating: "4.0", price: "3", lat: "30.4552247493", long: "78.0827539042", address: "1, London House, Picture Palace, Mussoorie", url: "https://www.zomato.com/mussoorie/little-llama-café-the-mall-road?utm_source=api_basic_user&utm_medium=api&utm_campaign=v2.1")
          // The app should add the restaurant successfully
        XCTAssertTrue(response)
    }
    
    /// Test adding a restaurant which already exixts
    ///
    /// Business logic: There should not be two restaurants with same id
    /*
     - The app should not enable already existing restaurant to be added to the DB
     
     */
    func testAddingAlreadyExistRestaurant(){
        precondition(model.isRestaurantExist("100100"))
        //create a restaurant object and add it to the db
        let response = model.addRestaurant(id: "100100", name: "LiTTle LLAMA Café", photoName: "https://b.zmtcdn.com/data/pictures/0/18702400/fc47e77bdd5bc3b73cf617eeafb3931c.jpg?fit=around%7C200%3A200&crop=200%3A200%3B%2A%2C%2A", rating: "4.0", price: "3", lat: "30.4552247493", long: "78.0827539042", address: "1, London House, Picture Palace, Mussoorie", url: "https://www.zomato.com/mussoorie/little-llama-café-the-mall-road?utm_source=api_basic_user&utm_medium=api&utm_campaign=v2.1")
        // The app should not add the already exist restaurant
        XCTAssertFalse(response)
    }
    
    /// Test adding a favourite item
    ///
    /// Business logic: There should  be a restaurants to be added to a favourites list
    /*
     - The app should enable useres to add a restaurant to the favourites list
     
     */
    func testAddingFavourite(){
        //there must be at least one restaurant in the db
        precondition(model.isRestaurantExist("100100"))
        let restaurant = model.getRestaurant("100100")
        let response = model.addFavorite(fav_comment: "", resturant: restaurant!)
        // The app should add the restaurant successfully
        XCTAssertTrue(response)
    }
    
    // Test method combinations
    ///
    /// Test updating a note/comment of a favourited item
    ///
    /// Business logic:
    /*
     -  There should be a restaurant already added
     -  This restaurant should be added to the favourties list
     
     - The app should enable useres to edit a comment of a favourited item
     
     */
    func testUpdatingComment(){
       //the restaurant  must be exist in the db
        precondition(model.isRestaurantExist("100100"))
        let restaurant = model.getRestaurant("100100")
        
       // should pass successfuly
        XCTAssertTrue(model.isRestaurantExist("100100"))
        
        //the restaurant  must be added to the favourite list
        model.addFavorite(fav_comment: "", resturant: restaurant!)
        XCTAssertTrue(model.isResturantAddedToFav(restaurant!))
        
        //the item  must be exist in the favourites list
        let favourite = model.gitFavouriteItem((restaurant?.id)!)
        XCTAssertTrue(favourite != nil)
        
        //test updating note/comment function
        let response = model.saveFavorite(fav_comment: "So Yummmmmmy !", favourite: favourite!)
        
        // The app should save the new comment successfully
        XCTAssertTrue(response)
    }
    
    
    
}
